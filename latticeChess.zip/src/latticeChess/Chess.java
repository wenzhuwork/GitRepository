package latticeChess;

public class Chess {
	public static void main(String[] args) {
		new ChessGUI();
	}
}



















