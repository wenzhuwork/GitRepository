package latticeChess;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;

@SuppressWarnings("serial")
public class ChessGUI extends JPanel {
	static int[] block = new int[25];
	static int[] redBox = new int[15];
	static int[] blueBox = new int[15];
	static int[] side = new int[50];
	static int[] redSide = new int[30];
	static int[] blueSide = new int[30];
	static int player = 0;// 0��ʾ�췽��1��ʾ����
	static int color = 0;// 0��ʾ��ɫ��1��ʾ��ɫ
	static int INITHEIGHT = 22;
	static int INITWIDTH = 22;
	static int redBlock = 0;
	static int blueBlock = 0;

	JFrame frame;
	Graphics g;
	JMenuBar menuBar;
	JMenu menuFile;
	JMenu menuChoice;
	JMenuItem menuItemOpen;
	JMenuItem menuItemSave;
	JMenuItem menuItemStart;
	JMenuItem menuItemRevoke;

	public ChessGUI() {
		frame = new JFrame("�����  @С�ֶ�3");
		frame.setSize(600, 600);
		menuBar = new JMenuBar();
		menuFile = new JMenu("�ļ�F");
		menuFile.setMnemonic('F');
		menuChoice = new JMenu("ѡ��C");
		menuChoice.setMnemonic('C');
		menuItemOpen = new JMenuItem("��O", 'O');
		menuItemSave = new JMenuItem("����S", 'S');
		menuItemStart = new JMenuItem("��ʼB", 'B');
		menuItemRevoke = new JMenuItem("����R", 'R');
		menuBar.add(menuFile);
		menuBar.add(menuChoice);
		menuFile.add(menuItemOpen);
		menuFile.add(menuItemSave);
		menuChoice.add(menuItemStart);
		menuChoice.add(menuItemRevoke);
		frame.setJMenuBar(menuBar);
		frame.add(this);
		frame.setLocationRelativeTo(null);
		frame.setResizable(false);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
		addMouseListener(new Monitor(this));
		g = frame.getContentPane().getGraphics();
		this.paint(g);
	}

	public void paint(Graphics g) {
		// ������
		Graphics2D g2d = (Graphics2D) g;
		g2d.setStroke(new BasicStroke(2.2f));
		for (int i = 0; i < 6; i++) {
			g.setColor(Color.gray);
			g.drawLine(20, 20 + i * 100, 520, 20 + 100 * i);
			g.drawLine(20 + 100 * i, 20, 20 + 100 * i, 520);
		}
		for (int i = 0; i < 6; i++) {
			for (int j = 0; j < 6; j++) {
				g.setColor(Color.black);
				g.fillOval(15 + 100 * j, 15 + i * 100, 10, 10);
			}

		}

		// ���߹�����
		if (redSide != null || blueSide != null) {
			for (int i = 0; i < redSide.length; i++) {
				int xf = (redSide[i] / 100) / 10;
				int yf = (redSide[i] / 100) % 10;
				int xl = (redSide[i] % 100) / 10;
				int yl = (redSide[i] % 100) % 10;
				g2d.setStroke(new BasicStroke(5.5f));
				g.setColor(Color.red);
				// ����-1��Ϊ�˸�����������
				g.drawLine(xf * 100 + ChessGUI.INITWIDTH - 1, yf * 100 + ChessGUI.INITHEIGHT - 1,
						xl * 100 + ChessGUI.INITWIDTH - 1, yl * 100 + ChessGUI.INITHEIGHT - 1);
			}
			
			for (int i = 0; i < blueSide.length; i++) {
				int xf = (blueSide[i] / 100) / 10;
				int yf = (blueSide[i] / 100) % 10;
				int xl = (blueSide[i] % 100) / 10;
				int yl = (blueSide[i] % 100) % 10;
				g2d.setStroke(new BasicStroke(5.5f));
				g.setColor(Color.blue);
				// ����-1��Ϊ�˸�����������
				g.drawLine(xf * 100 + ChessGUI.INITWIDTH - 1, yf * 100 + ChessGUI.INITHEIGHT - 1,
						xl * 100 + ChessGUI.INITWIDTH - 1, yl * 100 + ChessGUI.INITHEIGHT - 1);
			}
		}

		// ���Ѿ���ռ�ݵĸ���
		if (redBox != null || blueBox != null) {
			for (int i = 0; i < redBox.length; i++) {
				if (redBox[i] == 4) {
					g.setColor(Color.red);
					g.fillRect(ChessGUI.INITWIDTH - 1 + (i % 5) * 100, ChessGUI.INITHEIGHT - 1 + (i / 5) * 100, 100,
							100);
				}

			}

			for (int i = 0; i < blueBox.length; i++) {
				if (blueBox[i] == 4) {
					g.setColor(Color.blue);
					g.fillRect(ChessGUI.INITWIDTH - 1 + (i % 5) * 100, ChessGUI.INITHEIGHT - 1 + (i / 5) * 100, 100,
							100);
				}
			}
		}
	}

}
